# Design notes

## Time-Credit economy
- Teacher earns credits equal to session minutes; learner spends the same amount.
- New users get a small starting balance (default 30) so they can learn first.
- A learner cannot book a session if their balance is below the session length.

## Matching
Score = number of skills user A can teach that B wants + the reverse.
Mutual matches (both directions > 0) rank first, then by reputation.

## Reputation
Average of 1-5 star ratings, weighted toward recent sessions; new users start neutral (3.0).

## Open questions
- Different skills may deserve different credit rates.
- How to handle no-shows and fake sessions.
