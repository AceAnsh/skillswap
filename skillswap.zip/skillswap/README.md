# SkillSwap

**Peer-to-peer micro-mentorship where time is the currency.**
Teach 30 minutes of Python, earn 30 Time-Credits, spend them learning C from someone else.

By [Ansh Tiwari](https://github.com/AceAnsh) · [LinkedIn](https://linkedin.com/in/ansh-tiwari-916113407) · anshtiwari0072308@gmail.com

## Idea

Learning platforms cost money; tutoring is expensive. SkillSwap lets students barter knowledge:

- **Time-Credits**: 1 minute taught = 1 credit earned; 1 minute learned = 1 credit spent.
- **Skill matching**: pairs people whose "can teach" and "want to learn" skills complement each other.
- **Micro-sessions**: short 20-30 minute sessions, easy to fit between classes.
- **Shared workspace** (planned): collaborative code editor, video call, whiteboard.
- **Trust and reputation** (planned): ratings after each session build a reputation score.

## Project status

| Module | Status |
|---|---|
| Time-Credit ledger (`skillswap/credits.py`) | Done (prototype) |
| Skill matching (`skillswap/matching.py`) | Done (prototype) |
| Reputation (`skillswap/reputation.py`) | Done (prototype) |
| CLI demo (`skillswap/cli.py`) | Done |
| Web API | Planned |
| Shared workspace (editor/video/whiteboard) | Planned |

## Quick start

```bash
git clone https://github.com/AceAnsh/skillswap.git
cd skillswap
python -m skillswap.cli          # run the demo
python -m unittest discover tests  # run tests
```

Requires Python 3.9+. No external dependencies yet.

## Structure

```
skillswap/
  models.py      # User dataclass
  credits.py     # Time-Credit ledger
  matching.py    # skill matching algorithm
  reputation.py  # rating / trust score
  cli.py         # demo
tests/           # unit tests
docs/            # design notes
```

## Roadmap

1. Persist users and ledger (SQLite)
2. REST API (FastAPI)
3. Web frontend + session booking
4. Real-time workspace (WebRTC + collaborative editor)
5. Anti-abuse: no-show penalties, rating weighting

## Contributing

Issues and pull requests are welcome.

## License

MIT
