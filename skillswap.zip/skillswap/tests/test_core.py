import unittest

from skillswap.credits import InsufficientCredits, Ledger
from skillswap.matching import find_matches
from skillswap.models import User
from skillswap.reputation import score


class TestLedger(unittest.TestCase):
    def test_transfer(self):
        l = Ledger(starting_balance=30)
        l.record_session("a", "b", 20)
        self.assertEqual(l.balance("a"), 50)
        self.assertEqual(l.balance("b"), 10)

    def test_insufficient(self):
        l = Ledger(starting_balance=10)
        with self.assertRaises(InsufficientCredits):
            l.record_session("a", "b", 30)


class TestMatching(unittest.TestCase):
    def test_mutual_ranked_first(self):
        me = User("me", {"python"}, {"c"})
        mutual = User("m", {"c"}, {"python"})
        oneway = User("o", {"guitar"}, {"python"})
        self.assertEqual(find_matches(me, [oneway, mutual]), [mutual, oneway])

    def test_no_overlap(self):
        me = User("me", {"python"}, {"c"})
        self.assertEqual(find_matches(me, [User("x", {"art"}, {"chess"})]), [])


class TestReputation(unittest.TestCase):
    def test_neutral(self):
        self.assertEqual(score([]), 3.0)

    def test_recent_weighted(self):
        self.assertGreater(score([1, 5]), score([5, 1]))


if __name__ == "__main__":
    unittest.main()
