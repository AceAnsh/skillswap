def score(ratings, neutral=3.0):
    """Average rating (1-5), weighting recent ratings more. Neutral if none."""
    if not ratings:
        return neutral
    weights = [i + 1 for i in range(len(ratings))]  # later = more recent
    return sum(r * w for r, w in zip(ratings, weights)) / sum(weights)
