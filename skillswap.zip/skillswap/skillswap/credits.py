class InsufficientCredits(Exception):
    pass


class Ledger:
    """Tracks Time-Credit balances. 1 minute taught = 1 credit."""

    def __init__(self, starting_balance=30):
        self.starting_balance = starting_balance
        self.balances = {}
        self.history = []

    def balance(self, name):
        return self.balances.setdefault(name, self.starting_balance)

    def record_session(self, teacher, learner, minutes):
        if minutes <= 0:
            raise ValueError("minutes must be positive")
        if self.balance(learner) < minutes:
            raise InsufficientCredits(f"{learner} needs {minutes} credits")
        self.balances[learner] -= minutes
        self.balances[teacher] = self.balance(teacher) + minutes
        self.history.append((teacher, learner, minutes))
