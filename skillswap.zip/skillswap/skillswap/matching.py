from .reputation import score


def match_score(a, b):
    """Return (a_teaches_b, b_teaches_a) skill overlap counts."""
    return len(a.teaches & b.wants), len(b.teaches & a.wants)


def find_matches(user, others):
    """Rank other users: mutual swaps first, then one-way, then reputation."""
    results = []
    for other in others:
        if other is user:
            continue
        give, get = match_score(user, other)
        if give == 0 and get == 0:
            continue
        mutual = give > 0 and get > 0
        results.append((mutual, give + get, score(other.ratings), other))
    results.sort(key=lambda r: (r[0], r[1], r[2]), reverse=True)
    return [r[3] for r in results]
