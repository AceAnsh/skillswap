from .credits import Ledger
from .matching import find_matches
from .models import User


def main():
    ansh = User("Ansh", teaches={"python"}, wants={"c"})
    riya = User("Riya", teaches={"c"}, wants={"python"}, ratings=[5, 4])
    sam = User("Sam", teaches={"guitar"}, wants={"python"})
    users = [ansh, riya, sam]

    print("Matches for Ansh:", [u.name for u in find_matches(ansh, users)])

    ledger = Ledger()
    ledger.record_session(teacher="Ansh", learner="Riya", minutes=30)
    ledger.record_session(teacher="Riya", learner="Ansh", minutes=30)
    print("Balances:", ledger.balances)


if __name__ == "__main__":
    main()
