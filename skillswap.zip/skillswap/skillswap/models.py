from dataclasses import dataclass, field


@dataclass
class User:
    name: str
    teaches: set = field(default_factory=set)
    wants: set = field(default_factory=set)
    ratings: list = field(default_factory=list)

    def __post_init__(self):
        self.teaches = {s.lower() for s in self.teaches}
        self.wants = {s.lower() for s in self.wants}
